using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Models;
using Repositories.Repository;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class UserController : Controller
    {
        private readonly IUserRepository _userRepository;
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public UserController(IUserRepository userRepository, IWebHostEnvironment hostingEnvironment, IHttpContextAccessor httpContextAccessor)
        {
            _userRepository = userRepository;
            _hostingEnvironment = hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
        }


         [Route("")]
        public IActionResult Index()
        {
            ViewBag.IsAuthenticated = false;

            return View();
        }



        public IActionResult Register()
        {
            // ViewBag.IsAuthenticated = false;
            return View();
        }

        [HttpPost]
        public IActionResult Register(User user)
        {
           
                _userRepository.Register(user);
              
               
                return RedirectToAction("Login", "User");
          

            // If validation fails, return to the registration page with validation errors
            // ViewBag.IsAuthenticated = false;
        }



        public IActionResult Login()
        {
            ViewBag.IsAuthenticated = false;
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login(User user)
        {
            _httpContextAccessor.HttpContext.Session.SetString("email", user.c_email);
        _httpContextAccessor.HttpContext.Session.SetString("password", user.c_password);
        // _httpContextAccessor.HttpContext.Session.SetInt32("userid", user.c_userid);
        // _httpContextAccessor.HttpContext.Session.SetString("username", user.c_username);
            // if (string.IsNullOrEmpty(user.c_email) || string.IsNullOrEmpty(user.c_password))
        
            User loginUser = _userRepository.Login(user.c_email, user.c_password);
            if (loginUser != null)
            {
                var session = _httpContextAccessor.HttpContext.Session;

                // session.SetInt32("IsAuthenticated", 1); // Set IsAuthenticated to 1 (true)
                // ViewBag.IsAuthenticated = true;
                if (user.c_email.Equals("admin@gmail.com") && user.c_password.Equals("123"))
                {
                    // ViewBag.IsAuthenticated = true;
                    return RedirectToAction("Index", "Admin");
                }
                // ViewBag.IsAuthenticated = true;
                        // _httpContextAccessor.HttpContext.Session.SetString("username", user.c_username);

                return RedirectToAction("Index", "Shopping");
            }
            else
            {
                // ViewBag.IsAuthenticated = false; // Set it explicitly to false
                ViewData["ErrorMessage"] = "Wrong email or password. Please try again.";
                return View(user);
            }
        }



        public IActionResult Logout()
        {
            var session = _httpContextAccessor.HttpContext.Session;
            session.Clear(); // Clear all session data
            ViewBag.IsAuthenticated = false;
            return RedirectToAction("Index", "User");
        }






        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}