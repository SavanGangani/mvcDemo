using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories. Models
{
    public class Executive
    {
          public string t_userid{get;set;}
        public string t_userpassword{get;set;}
        public string t_usertype{get;set;}
    }
}