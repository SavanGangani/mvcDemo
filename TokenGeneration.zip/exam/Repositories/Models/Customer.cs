using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories. Models
{
    public class Customer
    {
         public string c_tokenid{get;set;}
        public string c_tokentype{get;set;}
        public string c_tokenstatus{get;set;}
        public string c_username{get;set;}
        public string c_usermobile{get;set;}
    }
}