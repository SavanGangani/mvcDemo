using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace mvc.Models
{
    public class Designation
    {
        public int c_id { get; set; }
        public string c_designation { get; set; }
    }
}